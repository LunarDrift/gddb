package main

import (
	"context"
	"database/sql"
	"time"

	"github.com/LunarDrift/deadabase/internal/database"
)

// fakeQuerier is a fake 'database' with all the methods required to satisfy ShowQuerier. Used so
// tests don't require a connection to the real database
type fakeQuerier struct {
	// Shows
	allShowIDs                   []int32
	allShowIDsErr                error
	allVenues                    []string
	allVenuesErr                 error
	allLocations                 []string
	allLocationsErr              error
	allCities                    []string
	allCitiesErr                 error
	showFromIDRows               []database.GetShowFromIDRow
	showFromIDErr                error
	showFromDateRows             []database.GetShowFromDateRow
	showFromDateErr              error
	showsFromTodaysDateRows      []database.GetShowsFromTodaysDateRow
	showsFromTodaysDateErr       error
	showsBetweenDatesRows        []database.GetShowsBetweenDatesRow
	showsBetweenDatesErr         error
	showsFromSongNameRows        []database.GetShowsFromSongNameRow
	showsFromSongNameErr         error
	showsFromSetNameRows         []database.GetShowsFromSetNameRow
	showsFromSetNameErr          error
	showsFromVenueNameRows       []database.SearchByVenueRow
	showsFromVenueNameErr        error
	showsFromLocationRows        []database.GetShowsFromLocationRow
	showsFromLocationErr         error
	showsFromCityRows            []database.GetShowsFromCityRow
	showsFromCityErr             error
	showsFromYearRows            []database.GetShowsFromYearRow
	showsFromYearErr             error
	showsFromYearAndLocationRows []database.GetShowsFromYearAndLocationRow
	showsFromYearAndLocationErr  error
	showsWithNotesRows           []database.ShowsWithShowNotesRow
	showsWithNotesErr            error
	showsWithoutNotesRows        []database.ShowsWithoutNotesRow
	showsWithoutNotesErr         error
	listVenueStats               []database.ListVenueStatsRow
	listVenueStatsErr            error
	// Songs
	songStatsRow            database.SongStatsRow
	songStatsErr            error
	songsPlayedAtVenueRows  []database.AllSongsPlayedAtVenueRow
	songsPlayedAtVenueErr   error
	songsFromSetNameRows    []database.MostCommonSongsBySetNameRow
	songsFromSetNameErr     error
	songsMostPlayedRows     []database.MostPlayedSongsRow
	songsMostplayedErr      error
	songsUniquePerCityRows  []database.UniqueSongsPerCityRow
	songsUniquePerCityErr   error
	songsPlayedLessThanRows []database.SongsPlayedLessThanRow
	songsPlayedLessThanErr  error
	listSongStatsRow        []database.ListSongStatsRow
	listSongStatsErr        error
	// Other
	validLocationRows []string
	validLocationErr  error
	footnoteRows      []database.GetFootnotesFromShowIDRow
	footnoteErr       error
}

func (f *fakeQuerier) ListVenueStats(ctx context.Context) ([]database.ListVenueStatsRow, error) {
	return f.listVenueStats, f.listVenueStatsErr
}

func (f *fakeQuerier) GetAllVenues(ctx context.Context) ([]string, error) {
	return f.allVenues, f.allVenuesErr
}

func (f *fakeQuerier) GetAllLocations(ctx context.Context) ([]string, error) {
	return f.allLocations, f.allLocationsErr
}

func (f *fakeQuerier) GetAllShowIDs(ctx context.Context) ([]int32, error) {
	return f.allShowIDs, f.allShowIDsErr
}

func (f *fakeQuerier) GetAllCities(ctx context.Context) ([]string, error) {
	return f.allCities, f.allCitiesErr
}

func (f *fakeQuerier) GetShowFromID(ctx context.Context, showID int32) ([]database.GetShowFromIDRow, error) {
	return f.showFromIDRows, f.showFromIDErr
}

func (f *fakeQuerier) GetShowFromDate(ctx context.Context, showDate time.Time) ([]database.GetShowFromDateRow, error) {
	return f.showFromDateRows, f.showFromDateErr
}

func (f *fakeQuerier) GetShowsFromTodaysDate(ctx context.Context, arg database.GetShowsFromTodaysDateParams) ([]database.GetShowsFromTodaysDateRow, error) {
	return f.showsFromTodaysDateRows, f.showsFromTodaysDateErr
}

func (f *fakeQuerier) GetShowsBetweenDates(ctx context.Context, arg database.GetShowsBetweenDatesParams) ([]database.GetShowsBetweenDatesRow, error) {
	return f.showsBetweenDatesRows, f.showsBetweenDatesErr
}

func (f *fakeQuerier) GetShowsFromSetName(ctx context.Context, arg database.GetShowsFromSetNameParams) ([]database.GetShowsFromSetNameRow, error) {
	return f.showsFromSetNameRows, f.showsFromSetNameErr
}

func (f *fakeQuerier) GetShowsFromSongName(ctx context.Context, arg database.GetShowsFromSongNameParams) ([]database.GetShowsFromSongNameRow, error) {
	return f.showsFromSongNameRows, f.showsFromSongNameErr
}

func (f *fakeQuerier) GetShowsFromLocation(ctx context.Context, arg database.GetShowsFromLocationParams) ([]database.GetShowsFromLocationRow, error) {
	return f.showsFromLocationRows, f.showsFromLocationErr
}

func (f *fakeQuerier) GetShowsFromYear(ctx context.Context, arg database.GetShowsFromYearParams) ([]database.GetShowsFromYearRow, error) {
	return f.showsFromYearRows, f.showsFromYearErr
}

func (f *fakeQuerier) GetShowsFromYearAndLocation(ctx context.Context, arg database.GetShowsFromYearAndLocationParams) ([]database.GetShowsFromYearAndLocationRow, error) {
	return f.showsFromYearAndLocationRows, f.showsFromYearAndLocationErr
}

func (f *fakeQuerier) SearchByVenue(ctx context.Context, arg database.SearchByVenueParams) ([]database.SearchByVenueRow, error) {
	return f.showsFromVenueNameRows, f.showsFromVenueNameErr
}

func (f *fakeQuerier) ShowsWithShowNotes(ctx context.Context, arg database.ShowsWithShowNotesParams) ([]database.ShowsWithShowNotesRow, error) {
	return f.showsWithNotesRows, f.showsWithNotesErr
}

func (f *fakeQuerier) ShowsWithoutNotes(ctx context.Context, arg database.ShowsWithoutNotesParams) ([]database.ShowsWithoutNotesRow, error) {
	return f.showsWithoutNotesRows, f.showsWithoutNotesErr
}

func (f *fakeQuerier) SongStats(ctx context.Context, songName sql.NullString) (database.SongStatsRow, error) {
	return f.songStatsRow, f.songStatsErr
}

func (f *fakeQuerier) AllSongsPlayedAtVenue(ctx context.Context, arg database.AllSongsPlayedAtVenueParams) ([]database.AllSongsPlayedAtVenueRow, error) {
	return f.songsPlayedAtVenueRows, f.songsPlayedAtVenueErr
}

func (f *fakeQuerier) MostCommonSongsBySetName(ctx context.Context, arg database.MostCommonSongsBySetNameParams) ([]database.MostCommonSongsBySetNameRow, error) {
	return f.songsFromSetNameRows, f.songsFromSetNameErr
}

func (f *fakeQuerier) MostPlayedSongs(ctx context.Context, arg database.MostPlayedSongsParams) ([]database.MostPlayedSongsRow, error) {
	return f.songsMostPlayedRows, f.songsMostplayedErr
}

func (f *fakeQuerier) SongsPlayedLessThan(ctx context.Context, arg database.SongsPlayedLessThanParams) ([]database.SongsPlayedLessThanRow, error) {
	return f.songsPlayedLessThanRows, f.songsPlayedLessThanErr
}

func (f *fakeQuerier) UniqueSongsPerCity(ctx context.Context, arg database.UniqueSongsPerCityParams) ([]database.UniqueSongsPerCityRow, error) {
	return f.songsUniquePerCityRows, f.songsUniquePerCityErr
}

func (f *fakeQuerier) GetFootnotesFromShowID(ctx context.Context, showID int32) ([]database.GetFootnotesFromShowIDRow, error) {
	return f.footnoteRows, f.footnoteErr
}

func (f *fakeQuerier) GetValidLocations(ctx context.Context) ([]string, error) {
	return f.validLocationRows, f.validLocationErr
}

func (f *fakeQuerier) GetShowsFromCity(ctx context.Context, arg database.GetShowsFromCityParams) ([]database.GetShowsFromCityRow, error) {
	return f.showsFromCityRows, f.showsFromCityErr
}

func (f *fakeQuerier) ListSongStats(ctx context.Context) ([]database.ListSongStatsRow, error) {
	return f.listSongStatsRow, f.listSongStatsErr
}
