package main

import (
	"database/sql"
	"fmt"
	"net/http"
	"slices"
	"strconv"
	"strings"
	"time"

	"github.com/LunarDrift/deadabase/internal"
	"github.com/LunarDrift/deadabase/internal/database"
)

func (s *server) handleSongsFromQueryParam(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()

	switch {
	case query.Get("sort") == "most_played" && query.Has("set_name"):
		s.handleGetMostPlayedSongsBySetName(w, r)

	case query.Get("sort") == "most_played":
		s.handleGetMostPlayedSongs(w, r)

	case query.Has("played_lt"):
		s.handleGetSongsPlayedLessThanNTimes(w, r)

	case query.Has("venue"):
		s.handleGetSongsPlayedAtVenue(w, r)

	default:
		msg := "Must provide a valid query parameter: played_lt, venue, sort=most_played, sort=most_played&set_name="
		respondWithError(w, http.StatusBadRequest, msg, nil)
		return
	}
}

func (s *server) handleGetMostPlayedSongs(w http.ResponseWriter, r *http.Request) {
	limit, offset, err := parsePagination(r)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, err.Error(), err)
		return
	}
	songRows, err := s.queries.MostPlayedSongs(r.Context(), database.MostPlayedSongsParams{
		PageOffset: int32(offset),
		PageLimit:  int32(limit),
	})
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Could not get most played songs", err)
		return
	}

	if len(songRows) == 0 && offset > 0 {
		respondWithError(w, http.StatusBadRequest, "Offset out of range", nil)
		return
	}
	if len(songRows) == 0 && offset == 0 {
		respondWithError(w, http.StatusInternalServerError, "Malformed song data", nil)
		return
	}

	next, prev := buildLinks(r, int(songRows[0].Count), offset, limit)
	results := internal.Paginated[internal.SongsTimesPlayed]{
		Count:    songRows[0].Count,
		Next:     next,
		Previous: prev,
		Results:  make([]internal.SongsTimesPlayed, 0, len(songRows)),
	}
	for _, row := range songRows {
		results.Results = append(results.Results, internal.RowToSongsTimesPlayed(row))
	}

	respondWithJSON(w, http.StatusOK, results)
}

func (s *server) handleGetSongsPlayedLessThanNTimes(w http.ResponseWriter, r *http.Request) {
	val := r.URL.Query().Get("played_lt")
	if val == "" {
		respondWithError(w, http.StatusBadRequest, "Missing parameter", nil)
		return
	}
	num, err := strconv.Atoi(val)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, "Invalid value. Expecting integer number", err)
		return
	}
	if num < 2 {
		respondWithError(w, http.StatusBadRequest, "Number should be at least 2", nil)
		return
	}

	limit, offset, err := parsePagination(r)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, err.Error(), err)
		return
	}

	songRows, err := s.queries.SongsPlayedLessThan(r.Context(), database.SongsPlayedLessThanParams{
		Column1:    int32(num),
		PageOffset: int32(offset),
		PageLimit:  int32(limit),
	})
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Could not get songs", err)
		return
	}

	if len(songRows) == 0 && offset > 0 {
		respondWithError(w, http.StatusBadRequest, "Offset out of range", nil)
		return
	}
	if len(songRows) == 0 && offset == 0 {
		respondWithError(w, http.StatusInternalServerError, "Malformed song data", nil)
		return
	}

	next, prev := buildLinks(r, int(songRows[0].Count), offset, limit)
	results := internal.Paginated[internal.SongsTimesPlayed]{
		Count:    songRows[0].Count,
		Next:     next,
		Previous: prev,
		Results:  make([]internal.SongsTimesPlayed, 0, len(songRows)),
	}
	for _, row := range songRows {
		results.Results = append(results.Results, internal.RowToSongsTimesPlayed(row))
	}

	respondWithJSON(w, http.StatusOK, results)
}

func (s *server) handleGetMostPlayedSongsBySetName(w http.ResponseWriter, r *http.Request) {
	setName := r.URL.Query().Get("set_name")
	if setName == "" {
		respondWithError(w, http.StatusBadRequest, "Missing 'set_name' parameter", nil)
		return
	}
	validSetNames := []string{"set_1", "set_2", "set_3", "encore", "acoustic_1", "acoustic_2", "acoustic", "electric"}
	if !slices.Contains(validSetNames, setName) {
		respondWithError(w, http.StatusBadRequest, fmt.Sprintf("Invalid set_name '%v'. Valid options: %s", setName, strings.Join(validSetNames, ", ")), nil)
		return
	}

	limit, offset, err := parsePagination(r)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, err.Error(), err)
		return
	}

	songRows, err := s.queries.MostCommonSongsBySetName(r.Context(), database.MostCommonSongsBySetNameParams{
		SetName:    setName,
		PageOffset: int32(offset),
		PageLimit:  int32(limit),
	})
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Could not get songs", err)
		return
	}

	if len(songRows) == 0 && offset > 0 {
		respondWithError(w, http.StatusBadRequest, "Offset out of range", nil)
		return
	}
	if len(songRows) == 0 && offset == 0 {
		respondWithError(w, http.StatusInternalServerError, "Malformed song data", nil)
		return
	}

	next, prev := buildLinks(r, int(songRows[0].Count), offset, limit)
	results := internal.Paginated[internal.SongsTimesPlayed]{
		Count:    songRows[0].Count,
		Next:     next,
		Previous: prev,
		Results:  make([]internal.SongsTimesPlayed, 0, len(songRows)),
	}
	for _, row := range songRows {
		results.Results = append(results.Results, internal.RowToSongsTimesPlayed(row))
	}

	respondWithJSON(w, http.StatusOK, results)
}

func (s *server) handleGetUniqueSongsPerCity(w http.ResponseWriter, r *http.Request) {
	limit, offset, err := parsePagination(r)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, err.Error(), err)
		return
	}
	songRows, err := s.queries.UniqueSongsPerCity(r.Context(), database.UniqueSongsPerCityParams{
		PageOffset: int32(offset),
		PageLimit:  int32(limit),
	})
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Could not get data", err)
		return
	}

	if len(songRows) == 0 && offset > 0 {
		respondWithError(w, http.StatusBadRequest, "Offset out of range", nil)
		return
	}
	if len(songRows) == 0 && offset == 0 {
		respondWithError(w, http.StatusInternalServerError, "Malformed song data", nil)
		return
	}

	next, prev := buildLinks(r, int(songRows[0].Count), offset, limit)
	results := internal.Paginated[internal.UniqueSongsPerCity]{
		Count:    songRows[0].Count,
		Next:     next,
		Previous: prev,
		Results:  make([]internal.UniqueSongsPerCity, 0, len(songRows)),
	}
	for _, row := range songRows {
		results.Results = append(results.Results, internal.UniqueSongsPerCity{
			City:            row.City,
			Location:        row.Location,
			UniqueSongCount: int(row.UniqueSongCount),
		})
	}

	respondWithJSON(w, http.StatusOK, results)
}

func (s *server) handleGetSongsPlayedAtVenue(w http.ResponseWriter, r *http.Request) {
	venue := r.URL.Query().Get("venue")
	if venue == "" {
		respondWithError(w, http.StatusBadRequest, "Missing 'venue' parameter", nil)
		return
	}
	searchPattern := fuzzyPattern(venue)

	limit, offset, err := parsePagination(r)
	if err != nil {
		respondWithError(w, http.StatusBadRequest, err.Error(), err)
		return
	}

	songRows, err := s.queries.AllSongsPlayedAtVenue(r.Context(), database.AllSongsPlayedAtVenueParams{
		VenueName:  searchPattern,
		PageOffset: int32(offset),
		PageLimit:  int32(limit),
	})
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "Could not get songs", err)
		return
	}

	if len(songRows) == 0 && offset > 0 {
		respondWithError(w, http.StatusBadRequest, "Offset out of range", nil)
		return
	}
	if len(songRows) == 0 && offset == 0 {
		respondWithError(w, http.StatusNotFound, "Venue not found", nil)
		return
	}

	next, prev := buildLinks(r, int(songRows[0].Count), offset, limit)
	results := internal.Paginated[internal.SongsFromVenue]{
		Count:    songRows[0].Count,
		Next:     next,
		Previous: prev,
		Results:  make([]internal.SongsFromVenue, 0, len(songRows)),
	}
	for _, row := range songRows {
		results.Results = append(results.Results, internal.SongsFromVenue{
			SongName: row.SongName.String,
			Venue:    row.Venue,
			City:     row.City,
			Location: row.Location,
		})
	}

	respondWithJSON(w, http.StatusOK, results)
}

func (s *server) handleGetSongStats(w http.ResponseWriter, r *http.Request) {
	song := r.PathValue("song")

	// NOTE: This can never actually happen client-side; `/songs/` without a parameter will 404.
	// But I'll keep it just in case I make changes in the future to /songs
	// And I'm asserting the 400 status code in the test. Otherwise I'd have to connect to the real server mux for a single test case
	if song == "" {
		respondWithError(w, http.StatusBadRequest, "Missing song name parameter", nil)
		return
	}

	searchPattern := fuzzyPattern(song)
	songStatRow, err := s.queries.SongStats(r.Context(), sql.NullString{String: searchPattern, Valid: true})
	if err != nil {
		respondWithError(w, http.StatusNotFound, "Song not found", err)
		return
	}

	respondWithJSON(w, http.StatusOK, internal.SongStats{
		TimesPlayed: int(songStatRow.TimesPlayed),
		FirstPlayed: songStatRow.FirstPlayed.Format(time.DateOnly),
		LastPlayed:  songStatRow.LastPlayed.Format(time.DateOnly),
	})
}

func (s *server) handleGetAllSongStats(w http.ResponseWriter, r *http.Request) {
	songStatsRows, err := s.queries.ListSongStats(r.Context())
	if err != nil {
		respondWithError(w, http.StatusInternalServerError, "could not get song stats", err)
		return
	}
	results := []internal.ListSongStatsRow{}
	for _, row := range songStatsRows {
		song := internal.ListSongStatsRow{
			Title:       row.Title,
			TimesPlayed: row.TimesPlayed,
			FirstPlayed: row.FirstPlayed,
			LastPlayed:  row.LastPlayed,
			Set1:        row.Set1,
			Set23:       row.Set23,
			Encore:      row.Encore,
			Acoustic:    row.Acoustic,
			Electric:    row.Electric,
		}
		results = append(results, song)
	}
	respondWithJSON(w, http.StatusOK, results)
}
