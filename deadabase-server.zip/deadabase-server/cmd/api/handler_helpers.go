package main

import (
	"encoding/json"
	"errors"
	"log"
	"log/slog"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/LunarDrift/deadabase/internal"
)

// pageURL, buildLinks, and parsePagination are helpers for pagination process

// pageURL: Add 'offset' and 'limit' query parameters to URL
func pageURL(r *http.Request, offset, limit int) *string {
	q := r.URL.Query()
	q.Set("offset", strconv.Itoa(offset))
	q.Set("limit", strconv.Itoa(limit))
	s := r.URL.Path + "?" + q.Encode()
	return &s
}

// buildLinks: Builds the Paginated response 'Next' and 'Previous' links
// based on the total number of results ('count') and current 'offset' and 'limit'
func buildLinks(r *http.Request, count, offset, limit int) (next, prev *string) {
	if offset+limit < count {
		next = pageURL(r, offset+limit, limit)
	}
	if offset > 0 {
		prev = pageURL(r, max(offset-limit, 0), limit)
	}
	return next, prev
}

// parsePagination: Sets default 'limit' and 'offset' query parameters if none are given.
// Default limit of 20. Max limit of 100.
func parsePagination(r *http.Request) (limit, offset int, err error) {
	limit, offset = 20, 0
	q := r.URL.Query()

	if v := q.Get("limit"); v != "" {
		if limit, err = strconv.Atoi(v); err != nil || limit < 1 {
			return 0, 0, errors.New("invalid 'limit' parameter")
		}
		limit = min(limit, 100) // cap so server doesn't send everything at once
	}
	if v := q.Get("offset"); v != "" {
		if offset, err = strconv.Atoi(v); err != nil || offset < 0 {
			return 0, 0, errors.New("invalid 'offset' parameter")
		}
	}
	return limit, offset, nil
}

// fuzzyPattern wraps and inserts a '%' between every word of `input` to be used during SQL ILIKE query searches
// e.g. "Help on the way > Slipknot! > Franklin's Tower" becomes "%Help%On%The%Way%>..."
func fuzzyPattern(input string) string {
	words := strings.Fields(input)
	if len(words) == 0 {
		return ""
	}
	return "%" + strings.Join(words, "%") + "%"
}

func respondWithJSON(w http.ResponseWriter, status int, payload any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	if err := json.NewEncoder(w).Encode(payload); err != nil {
		slog.SetLogLoggerLevel(slog.LevelError)
		log.Println("respondWithJSON - could not encode payload:", err)
	}
}

func respondWithError(w http.ResponseWriter, status int, message string, err error) {
	if err != nil {
		slog.SetLogLoggerLevel(slog.LevelError)
		log.Println(err)
	}
	type errorResponse struct {
		Error string `json:"error"`
	}
	respondWithJSON(w, status, errorResponse{Error: message})
}

// buildShowResponse takes a slice of ShowSortInput rows for a single show and returns
// a 'no setlist available' message if the show has no songs, otherwise sorting the
// sets + songs and attaching any footnotes, returning the completed show response.
func (s *server) buildShowResponse(r *http.Request, parsedShowRows []internal.ShowSortInput) (any, error) {
	if len(parsedShowRows) > 0 && parsedShowRows[0].RawEntry == "" {
		row := parsedShowRows[0]
		return internal.ShowWithNoSetlist{
			ShowID:   row.ShowID,
			Date:     row.Date.Format(time.DateOnly),
			Venue:    row.Venue,
			City:     row.City,
			Location: row.Location,
			Notes:    row.Notes,
			Message:  "No setlist available for this show",
		}, nil
	}

	showResp, err := internal.SortSetPositions(parsedShowRows)
	if err != nil {
		return nil, err
	}

	footnoteRows, err := s.queries.GetFootnotesFromShowID(r.Context(), parsedShowRows[0].ShowID)
	if err != nil {
		return nil, err
	}
	showResp.Footnotes = make(map[string]string)
	for _, f := range footnoteRows {
		showResp.Footnotes[f.Marker] = f.NoteText
	}

	return showResp, nil
}
