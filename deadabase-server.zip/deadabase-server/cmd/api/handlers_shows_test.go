package main

import (
	"database/sql"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/LunarDrift/deadabase/internal"
	"github.com/LunarDrift/deadabase/internal/database"
)

func TestHandleShowsFromPathVal_ByID(t *testing.T) {
	date, err := time.Parse(time.DateOnly, "1965-01-01")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	fake := &fakeQuerier{
		allShowIDs: []int32{42},
		showFromIDRows: []database.GetShowFromIDRow{
			{
				ShowID:   42,
				ShowDate: date,
				Venue:    "Fillmore West",
				City:     "San Francisco",
				Location: "CA",
				Notes:    sql.NullString{},
				SetName:  sql.NullString{String: "set_1", Valid: true},
				RawEntry: sql.NullString{String: "Dark Star", Valid: true},
			},
		},
		footnoteRows: []database.GetFootnotesFromShowIDRow{},
	}

	s := &server{queries: fake}

	req := httptest.NewRequest(http.MethodGet, "/shows/42", nil)
	req.SetPathValue("value", "42")
	w := httptest.NewRecorder()

	s.handleShowsFromPathVal(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status = %d; want 200", res.StatusCode)
	}

	got := internal.ShowResponse{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("failed to decode response: %v", err)
	}

	if got.Venue != "Fillmore West" {
		t.Errorf("got.Venue = %q; want %q", got.Venue, "Fillmore West")
	}
}

func TestHandleShowsFromPathVal_ByID_EmptySetlist(t *testing.T) {
	date, err := time.Parse(time.DateOnly, "1965-01-01")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	fake := &fakeQuerier{
		allShowIDs: []int32{42},
		showFromIDRows: []database.GetShowFromIDRow{
			{
				ShowID:   42,
				ShowDate: date,
				Venue:    "Fillmore West",
				City:     "San Francisco",
				Location: "CA",
				Notes:    sql.NullString{},
				SetName:  sql.NullString{},
				RawEntry: sql.NullString{},
			},
		},
		footnoteRows: []database.GetFootnotesFromShowIDRow{},
	}

	s := &server{queries: fake}

	req := httptest.NewRequest(http.MethodGet, "/shows/42", nil)
	req.SetPathValue("value", "42")
	w := httptest.NewRecorder()

	s.handleShowsFromPathVal(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status = %d; want 200", res.StatusCode)
	}

	got := internal.ShowWithNoSetlist{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("failed to decode response: %v", err)
	}

	expectedMessage := "No setlist available for this show"
	if got.Message != expectedMessage {
		t.Errorf("got.Message = %q; want %q", got.Message, expectedMessage)
	}
}

func TestHandleShowsFromPathVal_ByDate(t *testing.T) {
	date, err := time.Parse(time.DateOnly, "1969-09-30")
	if err != nil {
		t.Fatalf("unexpected error: %v", err)
	}

	fake := &fakeQuerier{
		showFromDateRows: []database.GetShowFromDateRow{
			{
				ShowID:   int32(1949),
				ShowDate: date,
				Venue:    "Cafe Au Go Go",
				City:     "New York",
				Location: "NY",
				Notes:    sql.NullString{},
				SetName:  sql.NullString{String: "set_1", Valid: true},
				RawEntry: sql.NullString{String: "China Cat Sunflower > I Know You Rider", Valid: true},
			},
		},
		footnoteRows: []database.GetFootnotesFromShowIDRow{},
	}

	s := &server{queries: fake}

	req := httptest.NewRequest(http.MethodGet, "/shows/1969-09-30", nil)
	req.SetPathValue("value", "1969-09-30")
	w := httptest.NewRecorder()

	s.handleShowsFromPathVal(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status = %d; want 200", res.StatusCode)
	}

	got := []internal.ShowResponse{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("failed to decode response: %v", err)
	}

	if len(got) != 1 {
		t.Errorf("len(got) = %v; want 1", len(got))
	}

	if got[0].Date != "1969-09-30" {
		t.Errorf("got.Date = %v; want 1969-09-30", got[0].Date)
	}
}

func TestHandleShowsFromPathVal_ByDate_EarlyLateShows(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1969-09-30")

	fake := &fakeQuerier{
		showFromDateRows: []database.GetShowFromDateRow{
			{
				ShowID: 1949, ShowDate: date, Venue: "Cafe Au Go Go", City: "New York", Location: "NY",
				SetName: sql.NullString{String: "set_1", Valid: true}, RawEntry: sql.NullString{String: "Early show song", Valid: true},
			},
			{
				ShowID: 1950, ShowDate: date, Venue: "Cafe Au Go Go", City: "New York", Location: "NY",
				SetName: sql.NullString{String: "set_1", Valid: true}, RawEntry: sql.NullString{String: "Late show song", Valid: true},
			},
		},
		footnoteRows: []database.GetFootnotesFromShowIDRow{},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows/1969-09-30", nil)
	req.SetPathValue("value", "1969-09-30")
	w := httptest.NewRecorder()

	s.handleShowsFromPathVal(w, req)

	got := []internal.ShowResponse{}
	if err := json.NewDecoder(w.Result().Body).Decode(&got); err != nil {
		t.Fatalf("failed to decode response: %v", err)
	}

	if len(got) != 2 {
		t.Errorf("len(got) = %d; want 2 (early + late show)", len(got))
	}

	if got[0].Date != got[1].Date {
		t.Errorf("got[0].Date = %q; want %q", got[0].Date, got[1].Date)
	}
}

func TestHandleShowsFromPathVal_ServerErr(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1969-09-30")
	tests := []struct {
		name string
		url  string
		val  string
		fake *fakeQuerier
	}{
		{name: "show query fails (date path)", url: "/shows/1969-09-30", val: "1969-09-30", fake: &fakeQuerier{
			showFromDateErr: errors.New("db exploded"),
		}},
		{name: "footnote query fails (date path)", url: "/shows/1969-09-30", val: "1969-09-30", fake: &fakeQuerier{
			showFromDateRows: []database.GetShowFromDateRow{
				{
					ShowID:   4,
					ShowDate: date,
					Venue:    "Soldier Field",
					City:     "Chicago",
					Location: "IL",
					SetName:  sql.NullString{String: "set_1", Valid: true},
					RawEntry: sql.NullString{String: "Dark Star", Valid: true},
				},
			},
			footnoteErr: errors.New("db exploded"),
		}},
		{name: "show query fails (id path)", url: "/shows/42", val: "42", fake: &fakeQuerier{
			allShowIDs:    []int32{42},
			showFromIDErr: errors.New("db exploded"),
		}},
		{name: "footnote query fails (id path)", url: "/shows/42", val: "42", fake: &fakeQuerier{
			allShowIDs: []int32{42},
			showFromIDRows: []database.GetShowFromIDRow{
				{
					ShowID:   42,
					ShowDate: date,
					Venue:    "Soldier Field",
					City:     "Chicago",
					Location: "IL",
					Notes:    sql.NullString{},
					SetName:  sql.NullString{String: "set_1", Valid: true},
					RawEntry: sql.NullString{String: "Dark Star", Valid: true},
				},
			},
			footnoteErr: errors.New("db exploded"),
		}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			req.SetPathValue("value", tt.val)
			w := httptest.NewRecorder()

			s.handleShowsFromPathVal(w, req)

			if got := w.Result().StatusCode; got != http.StatusInternalServerError {
				t.Errorf("status code = %d; want %d", got, http.StatusInternalServerError)
			}
		})
	}
}

func TestHandleGetShowsBetweenDates(t *testing.T) {
	startDate, _ := time.Parse(time.DateOnly, "1970-01-01")
	endDate, _ := time.Parse(time.DateOnly, "1970-01-31")
	fake := &fakeQuerier{
		showsBetweenDatesRows: []database.GetShowsBetweenDatesRow{
			{ShowID: 1, ShowDate: startDate, Venue: "test venue", City: "test city", Location: "test location", Notes: sql.NullString{}},
			{ShowID: 2, ShowDate: endDate, Venue: "test venue", City: "test city", Location: "test location", Notes: sql.NullString{}},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?start_date=1970-01-01&end_date=1970-01-31", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsBetweenDates(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Errorf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != len(fake.showsBetweenDatesRows) {
		t.Errorf("len(got) = %d; want %d", len(got.Results), len(fake.showsBetweenDatesRows))
	}

	if got.Results[0].Date != "1970-01-01" {
		t.Errorf("got.Results[0].Date = %q; want '1970-01-01'", got.Results[0].Date)
	}
}

func TestHandleShowsBetweenDates_StartDateAfterEndDate(t *testing.T) {
	// empty querier - validation should reject the request before ever getting to query step
	fake := &fakeQuerier{}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?start_date=1980-09-01&end_date=1980-02-01", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsBetweenDates(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusBadRequest {
		t.Errorf("status code = %d; want %d", res.StatusCode, http.StatusBadRequest)
	}
}

func TestHandleGetRandomShow_NoShowsAvailable(t *testing.T) {
	fake := &fakeQuerier{
		allShowIDs: []int32{},
	}
	s := &server{queries: fake}

	req := httptest.NewRequest(http.MethodGet, "/shows/random", nil)
	w := httptest.NewRecorder()

	s.handleGetRandomShow(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusInternalServerError {
		t.Errorf("status code = %d; want %d", res.StatusCode, http.StatusInternalServerError)
	}
}

func TestHandleGetShowsFromSongName(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-01-01")
	fake := &fakeQuerier{
		showsFromSongNameRows: []database.GetShowsFromSongNameRow{
			{ShowID: 1, ShowDate: date, Venue: "test venue", City: "test city", Location: "test location", Notes: sql.NullString{}},
			{ShowID: 2, ShowDate: date.Add(time.Hour * 48), Venue: "test venue 2", City: "test city 2", Location: "test location 2", Notes: sql.NullString{}},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?song=althea", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromSongName(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != len(fake.showsFromSongNameRows) {
		t.Errorf("len(got) = %d; want %d", len(got.Results), len(fake.showsFromSongNameRows))
	}

	if got.Results[0].Date != "1995-01-01" {
		t.Errorf("got.Results[0].Date = %q; want %q", got.Results[0].Date, "1995-01-01")
	}

	if got.Results[0].Venue != "test venue" {
		t.Errorf("got.Results[0].Venue = %q; want 'test venue'", got.Results[0].Venue)
	}
	if got.Results[1].Venue != "test venue 2" {
		t.Errorf("got.Results[1].Venue = %q; want 'test venue 2'", got.Results[1].Venue)
	}
}

func TestHandleGetShowsFromSongName_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"missing song name", "/shows?song=", http.StatusBadRequest, &fakeQuerier{}},
		{"invalid song name", "/shows?song=Drak_Star", http.StatusNotFound, &fakeQuerier{}},
		{"server error", "/shows?song=althea", http.StatusInternalServerError, &fakeQuerier{showsFromSongNameErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetShowsFromSongName(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("status code = %d; want %d", got, tt.wantStatus)
			}
		})
	}
}

func TestHandleGetShowsFromSetName(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-01-01")
	fake := &fakeQuerier{
		showsFromSetNameRows: []database.GetShowsFromSetNameRow{
			{ShowID: 1, ShowDate: date, Venue: "Soldier Field", City: "Chicago", Location: "test location", Notes: sql.NullString{}},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?set_name=encore", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromSetName(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if got.Results[0].ShowID != 1 {
		t.Errorf("got.Results[0].ShowID = %q; want 1", got.Results[0].ShowID)
	}
}

func TestHandleGetShowsFromSetName_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"missing set name", "/shows?set_name=", http.StatusBadRequest, &fakeQuerier{}},
		{"invalid set name", "/shows?set_name=hello", http.StatusBadRequest, &fakeQuerier{}},
		{"server error", "/shows?set_name=set_1", http.StatusInternalServerError, &fakeQuerier{showsFromSetNameErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetShowsFromSetName(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("status code = %d; want %d", got, tt.wantStatus)
			}
		})
	}
}

func TestHandleGetShowsFromVenueName(t *testing.T) {
	date1, _ := time.Parse(time.DateOnly, "1995-01-01")
	date2, _ := time.Parse(time.DateOnly, "1995-01-02")
	fake := &fakeQuerier{
		showsFromVenueNameRows: []database.SearchByVenueRow{
			{ShowID: 1, ShowDate: date1, Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
			{ShowID: 2, ShowDate: date2, Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?venue=soldier", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromVenueName(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].Venue != "Soldier Field" {
		t.Errorf("got.Results[0].Venue = %q; want %s", got.Results[0].Venue, "Soldier Field")
	}

	if got.Results[0].Venue != got.Results[1].Venue {
		t.Errorf("different venues: got.Results[0].Venue = %q, got.Results[1].Venue = %q", got.Results[0].Venue, got.Results[1].Venue)
	}
}

func TestHandleGetShowsFromVenueName_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"missing venue param", "/shows?venue=", http.StatusBadRequest, &fakeQuerier{}},
		{"invalid venue param", "/shows?venue=hello_world", http.StatusNotFound, &fakeQuerier{}},
		{"server error", "/shows?venue=deer_creek", http.StatusInternalServerError, &fakeQuerier{showsFromVenueNameErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetShowsFromVenueName(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("status code = %d; want %d", got, tt.wantStatus)
			}
		})
	}
}

func TestHandleGetShowsFromLocation(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-01-01")
	fake := &fakeQuerier{
		showsFromLocationRows: []database.GetShowsFromLocationRow{
			{ShowID: 1, ShowDate: date, Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
			{ShowID: 2, ShowDate: date.Add(24 * time.Hour), Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
		},
		validLocationRows: []string{"il", "england"},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?location=IL", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromLocation(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].Location != "IL" {
		t.Errorf("got.Results[0].Location = %q; want 'IL'", got.Results[0].Location)
	}

	if got.Results[0].Location != got.Results[1].Location {
		t.Errorf("different locations: got.Results[0].Location = %q, got.Results[1].Location = %q", got.Results[0].Location, got.Results[1].Location)
	}
}

func TestHandleGetShowsFromLocation_CountryName(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-01-01")
	fake := &fakeQuerier{
		showsFromLocationRows: []database.GetShowsFromLocationRow{
			{ShowID: 1, ShowDate: date, Venue: "Wembly Empire Pool", City: "London", Location: "England", Notes: sql.NullString{}},
		},
		validLocationRows: []string{"england", "il"},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?location=England", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromLocation(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 1 {
		t.Errorf("len(got) = %d; want 1", len(got.Results))
	}

	if got.Results[0].Location != "England" {
		t.Errorf("got.Results[0].Location = %q; want 'England'", got.Results[0].Location)
	}
}

func TestHandleGetShowsFromLocation_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"empty param", "/shows?location=", http.StatusBadRequest, &fakeQuerier{validLocationRows: []string{"IL", "England"}}},
		{"invalid param", "/shows?location=hello", http.StatusBadRequest, &fakeQuerier{validLocationRows: []string{"IL", "England"}}},
		{"server error", "/shows?location=IL", http.StatusInternalServerError, &fakeQuerier{showsFromLocationErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetShowsFromLocation(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("status code = %d; want %d", got, tt.wantStatus)
			}
		})
	}
}

func TestHandleGetShowsFromCity(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-01-01")
	fake := &fakeQuerier{
		showsFromCityRows: []database.GetShowsFromCityRow{
			{ShowID: 1, ShowDate: date, Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
			{ShowID: 2, ShowDate: date.Add(24 * time.Hour), Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?city=chicago", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromCity(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].City != "Chicago" {
		t.Errorf("got.Results[0].City = %q; want %q", got.Results[0].City, "Chicago")
	}
	if got.Results[1].City != "Chicago" {
		t.Errorf("got.Results[1].City = %q; want %q", got.Results[1].City, "Chicago")
	}
}

func TestHandleGetShowsFromCity_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"empty param", "/shows?city=", http.StatusBadRequest, &fakeQuerier{}},
		{"city not found", "/shows?city=abc", http.StatusNotFound, &fakeQuerier{}},
		{"server error", "/shows?city=reno", http.StatusInternalServerError, &fakeQuerier{showsFromCityErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetShowsFromCity(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("status code = %d; want %d", got, tt.wantStatus)
			}
		})
	}
}

func TestHandleGetShowsFromYear(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-01-01")
	fake := &fakeQuerier{
		showsFromYearRows: []database.GetShowsFromYearRow{
			{ShowID: 1, ShowDate: date, Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
			{ShowID: 2, ShowDate: date.Add(time.Hour * 24), Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?year=1995", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromYear(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].Date[:4] != "1995" {
		t.Errorf("got.Results[0].Date year %q; want '1995'", got.Results[0].Date[:4])
	}

	if got.Results[0].Date != "1995-01-01" {
		t.Errorf("got.Results[0].Date = %q; want '1995-01-01'", got.Results[0].Date)
	}
}

func TestHandleGetShowsFromYear_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"empty year param", "/shows?year=", http.StatusBadRequest, &fakeQuerier{}},
		{"invalid year", "/shows?year=1", http.StatusBadRequest, &fakeQuerier{}},
		{"invalid year string", "/shows?year=hello", http.StatusBadRequest, &fakeQuerier{}},
		{"server error", "/shows?year=1967", http.StatusInternalServerError, &fakeQuerier{showsFromYearErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetShowsFromYear(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("%q: status code = %d; want %d", tt.name, got, tt.wantStatus)
			}
		})
	}
}

func TestHandleGetShowsFromYearAndLocation(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-01-01")
	fake := &fakeQuerier{
		showsFromYearAndLocationRows: []database.GetShowsFromYearAndLocationRow{
			{ShowID: 1, ShowDate: date, Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
			{ShowID: 2, ShowDate: date.Add(time.Hour * 24), Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{}},
		},
		validLocationRows: []string{"england", "il"},
	}

	s := &server{queries: fake}

	req := httptest.NewRequest(http.MethodGet, "/shows?year=1995&location=IL", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromYearAndLocation(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].Location != "IL" {
		t.Errorf("got.Results[0].Location = %q; want 'IL'", got.Results[0].Location)
	}

	if got.Results[0].Date[:4] != "1995" {
		t.Errorf("got.Results[0].Date year = %q; want '1995'", got.Results[0].Date[:4])
	}
}

func TestHandleGetShowsFromYearAndLocation_CountryName(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-01-01")
	fake := &fakeQuerier{
		showsFromYearAndLocationRows: []database.GetShowsFromYearAndLocationRow{
			{ShowID: 1, ShowDate: date, Venue: "Wembly Stadium", City: "London", Location: "England", Notes: sql.NullString{}},
		},
		validLocationRows: []string{"england", "il"},
	}

	s := &server{queries: fake}

	req := httptest.NewRequest(http.MethodGet, "/shows?year=1995&location=England", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromYearAndLocation(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 1 {
		t.Errorf("len(got) = %d; want 1", len(got.Results))
	}

	if got.Results[0].Location != "England" {
		t.Errorf("got.Results[0].Location = %q; want 'England'", got.Results[0].Location)
	}

	if got.Results[0].Date[:4] != "1995" {
		t.Errorf("got.Results[0].Date year = %q; want '1995'", got.Results[0].Date[:4])
	}
}

func TestHandleGetShowsFromYearAndLocation_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"empty year param", "/shows?year=&location=IL", http.StatusBadRequest, &fakeQuerier{}},
		{"empty location param", "/shows?year=1995&location=", http.StatusBadRequest, &fakeQuerier{}},
		{"server error", "/shows?year=1965&location=CA", http.StatusInternalServerError, &fakeQuerier{showsFromYearAndLocationErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetShowsFromYearAndLocation(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("%q: status code = %d; want %d", tt.name, got, tt.wantStatus)
			}
		})
	}
}

func TestHandleGetShowsFromNotes_WithNotes(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-07-09")
	fake := &fakeQuerier{
		showsWithNotesRows: []database.ShowsWithShowNotesRow{
			{ShowID: 1, ShowDate: date, Venue: "Soldier Field", City: "Chicago", Location: "IL", Notes: sql.NullString{String: "Final show", Valid: true}},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?has_notes=true", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromNotes(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 1 {
		t.Errorf("len(got) = %d; want 1", len(got.Results))
	}

	if got.Results[0].Notes != "Final show" {
		t.Errorf("got.Results[0].Notes = %q; want 'Final show'", got.Results[0].Notes)
	}
}

func TestHandleGetShowsFromNotes_WithoutNotes(t *testing.T) {
	date, _ := time.Parse(time.DateOnly, "1995-07-09")
	fake := &fakeQuerier{
		showsWithoutNotesRows: []database.ShowsWithoutNotesRow{
			{ShowID: 1, ShowDate: date, Venue: "Soldier Field", City: "Chicago", Location: "IL"},
			{ShowID: 2, ShowDate: date.Add(time.Hour * 24), Venue: "Wembly", City: "London", Location: "England"},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/shows?has_notes=false", nil)
	w := httptest.NewRecorder()

	s.handleGetShowsFromNotes(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.ShowMeta]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].Notes != "" {
		t.Errorf("got.Results[0].Notes = %q; want ''", got.Results[0].Notes)
	}
}

func TestHandleGetShowsFromNotes_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"missing notes param", "/shows?has_notes=", http.StatusBadRequest, &fakeQuerier{}},
		{"invalid notes param", "/shows?has_notes=yes", http.StatusBadRequest, &fakeQuerier{}},
		{"server error", "/shows?has_notes=false", http.StatusInternalServerError, &fakeQuerier{showsWithoutNotesErr: errors.New("without notes: db exploded")}},
		{"server error", "/shows?has_notes=true", http.StatusInternalServerError, &fakeQuerier{showsWithNotesErr: errors.New("with notes: db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetShowsFromNotes(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("%q: status code = %d; want %d", tt.name, got, tt.wantStatus)
			}
		})
	}
}
