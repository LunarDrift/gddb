package main

import (
	"database/sql"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/LunarDrift/deadabase/internal"
	"github.com/LunarDrift/deadabase/internal/database"
)

func TestHandleGetSongStats(t *testing.T) {
	firstPlayed, _ := time.Parse(time.DateOnly, "1990-01-01")
	lastPlayed := firstPlayed.Add(time.Hour * 24)
	fake := &fakeQuerier{
		songStatsRow: database.SongStatsRow{
			TimesPlayed: 10, FirstPlayed: firstPlayed, LastPlayed: lastPlayed,
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/songs/althea", nil)
	req.SetPathValue("song", "althea")
	w := httptest.NewRecorder()

	s.handleGetSongStats(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.SongStats{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if got.FirstPlayed != "1990-01-01" {
		t.Errorf("got.FirstPlayed = %q; want '1990-01-01'", got.FirstPlayed)
	}
	if got.LastPlayed != "1990-01-02" {
		t.Errorf("got.LastPlayed = %q; want '1990-01-02'", got.LastPlayed)
	}
	if got.TimesPlayed != 10 {
		t.Errorf("got.TimesPlayed = %d; want 10", got.TimesPlayed)
	}
}

func TestHandleGetSongStats_MissingPathParam(t *testing.T) {
	fake := &fakeQuerier{}
	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/songs/", nil)
	w := httptest.NewRecorder()

	s.handleGetSongStats(w, req)
	res := w.Result()
	if res.StatusCode != http.StatusBadRequest {
		t.Errorf("status code = %d; want %d", res.StatusCode, http.StatusBadRequest)
	}
}

func TestHandleGetSongsPlayedAtVenue(t *testing.T) {
	fake := &fakeQuerier{
		songsPlayedAtVenueRows: []database.AllSongsPlayedAtVenueRow{
			{SongName: sql.NullString{String: "Althea", Valid: true}, Venue: "Soldier Field", City: "Chicago", Location: "IL"},
			{SongName: sql.NullString{String: "Dark Star", Valid: true}, Venue: "Soldier Field", City: "Chicago", Location: "IL"},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/songs?venue=soldier_field", nil)
	w := httptest.NewRecorder()

	s.handleGetSongsPlayedAtVenue(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.SongsFromVenue]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].Venue != "Soldier Field" {
		t.Errorf("got[0].Venue = %q; want 'Soldier Field'", got.Results[0].Venue)
	}

	if got.Results[1].Venue != "Soldier Field" {
		t.Errorf("got[1].Venue = %q; want 'Soldier Field'", got.Results[1].Venue)
	}

	if got.Results[0].Venue != got.Results[1].Venue {
		t.Errorf("different venues: got[0].Venue = %q; got[1].Venue = %q", got.Results[0].Venue, got.Results[1].Venue)
	}
}

func TestHandleGetSongsPlayedAtVenue_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"missing venue param", "/songs?venue=", http.StatusBadRequest, &fakeQuerier{}},
		{"invalid venue param", "/songs?venue=hello_world", http.StatusNotFound, &fakeQuerier{}},
		{"server error", "/songs?venue=deer_creek", http.StatusInternalServerError, &fakeQuerier{songsPlayedAtVenueErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetSongsPlayedAtVenue(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("status = %d; want %d", got, tt.wantStatus)
			}
		})
	}
}

func TestHandleGetMostPlayedSongsBySetName(t *testing.T) {
	fake := &fakeQuerier{
		songsFromSetNameRows: []database.MostCommonSongsBySetNameRow{
			{Song: sql.NullString{String: "Dark Star", Valid: true}, TimesPlayed: 10},
			{Song: sql.NullString{String: "Althea", Valid: true}, TimesPlayed: 8},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/songs?sort=most_played&set_name=encore", nil)
	w := httptest.NewRecorder()

	s.handleGetMostPlayedSongsBySetName(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.SongsTimesPlayed]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].TimesPlayed != 10 {
		t.Errorf("got[0].TimesPlayed = %d; want 10", got.Results[0].TimesPlayed)
	}
	if got.Results[1].TimesPlayed != 8 {
		t.Errorf("got[1].TimesPlayed = %d; want 8", got.Results[1].TimesPlayed)
	}
}

func TestHandleGetMostPlayedSongsBySetName_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"missing set name param", "/songs?set_name=", http.StatusBadRequest, &fakeQuerier{}},
		{"invalid set name param", "/songs?set_name=hello", http.StatusBadRequest, &fakeQuerier{}},
		{"server error", "/songs?set_name=encore", http.StatusInternalServerError, &fakeQuerier{songsFromSetNameErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetMostPlayedSongsBySetName(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("status code = %d; want %d", got, tt.wantStatus)
			}
		})
	}
}

func TestHandleGetMostPlayedSongs(t *testing.T) {
	fake := &fakeQuerier{
		songsMostPlayedRows: []database.MostPlayedSongsRow{
			{Song: sql.NullString{String: "Althea", Valid: true}, TimesPlayed: 100},
			{Song: sql.NullString{String: "Dark Star", Valid: true}, TimesPlayed: 90},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/songs?sort=most_played", nil)
	w := httptest.NewRecorder()

	s.handleGetMostPlayedSongs(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.SongsTimesPlayed]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].Song != "Althea" {
		t.Errorf("got[0].Song = %q; want 'Althea'", got.Results[0].Song)
	}
	if got.Results[1].Song != "Dark Star" {
		t.Errorf("got[1].Song = %q; want 'Dark Star'", got.Results[1].Song)
	}
}

func TestHandleGetMostPlayedSongs_ServerErr(t *testing.T) {
	fake := &fakeQuerier{songsMostplayedErr: errors.New("db exploded")}
	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/songs?sort=most_played", nil)
	w := httptest.NewRecorder()

	s.handleGetMostPlayedSongs(w, req)

	if got := w.Result().StatusCode; got != http.StatusInternalServerError {
		t.Errorf("status code = %d; want %d", got, http.StatusInternalServerError)
	}
}

func TestHandleUniqueSongsPerCity(t *testing.T) {
	fake := &fakeQuerier{
		songsUniquePerCityRows: []database.UniqueSongsPerCityRow{
			{City: "Chicago", Location: "IL", UniqueSongCount: 50},
			{City: "London", Location: "England", UniqueSongCount: 24},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/stats/songs-per-city", nil)
	w := httptest.NewRecorder()

	s.handleGetUniqueSongsPerCity(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.UniqueSongsPerCity]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].City != "Chicago" {
		t.Errorf("got[0].City = %q; want 'Chicago'", got.Results[0].City)
	}

	if got.Results[1].Location != "England" {
		t.Errorf("got[1].StateOrCountry = %q; want 'England'", got.Results[1].Location)
	}
	if got.Results[1].UniqueSongCount != 24 {
		t.Errorf("got[1].UniqueSongCount = %d; want 24", got.Results[1].UniqueSongCount)
	}
}

func TestHandleUniqueSongsPerCity_ServerErr(t *testing.T) {
	fake := &fakeQuerier{songsUniquePerCityErr: errors.New("db exploded")}
	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/stats/songs-per-city", nil)
	w := httptest.NewRecorder()

	s.handleGetUniqueSongsPerCity(w, req)

	if got := w.Result().StatusCode; got != http.StatusInternalServerError {
		t.Errorf("status code = %d; want %d", got, http.StatusInternalServerError)
	}
}

func TestHandleSongsPlayedLessThanNTimes(t *testing.T) {
	fake := &fakeQuerier{
		songsPlayedLessThanRows: []database.SongsPlayedLessThanRow{
			{Song: sql.NullString{String: "Althea", Valid: true}, TimesPlayed: 19},
			{Song: sql.NullString{String: "Dark Star", Valid: true}, TimesPlayed: 10},
		},
	}

	s := &server{queries: fake}
	req := httptest.NewRequest(http.MethodGet, "/songs?played_lt=20", nil)
	w := httptest.NewRecorder()

	s.handleGetSongsPlayedLessThanNTimes(w, req)

	res := w.Result()
	if res.StatusCode != http.StatusOK {
		t.Fatalf("status code = %d; want %d", res.StatusCode, http.StatusOK)
	}

	got := internal.Paginated[internal.SongsTimesPlayed]{}
	if err := json.NewDecoder(res.Body).Decode(&got); err != nil {
		t.Fatalf("error decoding response: %v", err)
	}

	if len(got.Results) != 2 {
		t.Errorf("len(got) = %d; want 2", len(got.Results))
	}

	if got.Results[0].Song != "Althea" {
		t.Errorf("got[0].Song = %q; want 'Althea'", got.Results[0].Song)
	}
	if got.Results[0].TimesPlayed != 19 {
		t.Errorf("got[0].TimesPlayed = %d; want 19", got.Results[0].TimesPlayed)
	}

	if got.Results[1].Song != "Dark Star" {
		t.Errorf("got[1].Song = %q; want 'Dark Star'", got.Results[1].Song)
	}
}

func TestHandleSongsPlayedLessThanNTimes_Errors(t *testing.T) {
	tests := []struct {
		name       string
		url        string
		wantStatus int
		fake       *fakeQuerier
	}{
		{"missing param", "/songs?played_lt=", http.StatusBadRequest, &fakeQuerier{}},
		{"invalid param", "/songs?played_lt=five", http.StatusBadRequest, &fakeQuerier{}},
		{"server error", "/songs?played_lt=10", http.StatusInternalServerError, &fakeQuerier{songsPlayedLessThanErr: errors.New("db exploded")}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &server{queries: tt.fake}
			req := httptest.NewRequest(http.MethodGet, tt.url, nil)
			w := httptest.NewRecorder()
			s.handleGetSongsPlayedLessThanNTimes(w, req)
			if got := w.Result().StatusCode; got != tt.wantStatus {
				t.Errorf("status code = %d; want %d", got, tt.wantStatus)
			}
		})
	}
}
