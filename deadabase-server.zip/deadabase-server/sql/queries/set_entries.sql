-- name: CreateSetEntry :one
INSERT INTO set_entries (
set_id,
raw_entry,
position
)
VALUES (
  $1,
  $2,
  $3
  )
ON CONFLICT (set_id, position) DO UPDATE
SET raw_entry = EXCLUDED.raw_entry
RETURNING id;

-- name: MostPlayedSongs :many
SELECT se.song_name AS song, COUNT(*) AS times_played, COUNT(*) OVER ()
FROM set_entries se
GROUP BY se.song_name
ORDER BY times_played DESC
LIMIT @page_limit OFFSET @page_offset;

-- name: SongsPlayedLessThan :many
SELECT se.song_name AS song, count(*) AS times_played, COUNT(*) OVER ()
FROM set_entries se
GROUP BY se.song_name
HAVING count(*) < $1::int
ORDER BY times_played DESC
LIMIT @page_limit OFFSET @page_offset;

-- name: MostCommonSongsBySetName :many
SELECT se.song_name AS song, COUNT(*) AS times_played, COUNT(*) OVER ()
FROM set_entries se
JOIN "sets" st ON se.set_id = st.id
WHERE st.set_name = @set_name
GROUP BY se.song_name
ORDER BY times_played DESC
LIMIT @page_limit OFFSET @page_offset;

-- name: UniqueSongsPerCity :many
SELECT sh.city, sh.state AS location, COUNT(DISTINCT se.song_name) AS unique_song_count, COUNT(*) OVER ()
FROM set_entries se
JOIN "sets" st ON se.set_id = st.id
JOIN shows sh ON st.show_id = sh.show_id
GROUP BY sh.city, sh.state
ORDER BY unique_song_count DESC
LIMIT @page_limit OFFSET @page_offset;

-- name: AllSongsPlayedAtVenue :many
SELECT *, COUNT(*) OVER ()
FROM (
  SELECT DISTINCT se.song_name, sh.venue, sh.city, sh.state AS location
  FROM set_entries se
  JOIN "sets" st ON se.set_id = st.id
  JOIN shows sh ON st.show_id = sh.show_id
  WHERE sh.venue ILIKE @venue_name
) sub
ORDER BY venue, song_name
LIMIT @page_limit OFFSET @page_offset;
