module github.com/LunarDrift/deadabase

go 1.27.1

require (
	github.com/joho/godotenv v1.5.1
	github.com/lib/pq v1.12.3
	github.com/lmittmann/tint v1.2.0
	github.com/mattn/go-isatty v0.0.23
	golang.org/x/time v0.15.0
)

require golang.org/x/sys v0.49.0 // indirect
